This repository contains a ReactJS Application project named as my-react-project.<br>
To run this project follow below instructions:<br>
First copy this project to desctop or any specific folder <br>
Next, open command prompt and change path to desctop or that particular directory where you have copied my-react-project folder.<br>
Type cd my-react-project (change directory to project folder)<br>
Now, type- npm start<br>
This command will run my-react-project and give you the URL where you will find desired website<br>
